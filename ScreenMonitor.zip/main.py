from ScreenMonitor import ScreenMonitor



if __name__ == "__main__":
ScreenMonitor.main()